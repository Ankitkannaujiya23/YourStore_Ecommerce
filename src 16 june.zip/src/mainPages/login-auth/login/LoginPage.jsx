import React from 'react'
import Login from './Login'

const LoginPage = () => {
  return (
    <div>
        <Login />
    </div>
  )
}

export default LoginPage