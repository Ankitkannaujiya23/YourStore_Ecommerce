import React from 'react'
import Signup from './Signup'

const SignupPage = () => {
  return (
    <div>
        <Signup/>
    </div>
  )
}

export default SignupPage