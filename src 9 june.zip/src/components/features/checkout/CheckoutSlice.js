import { createSlice } from "@reduxjs/toolkit";

const CheckoutSlice=createSlice({
    name:"Checkout_Sl",
    initialState:{
       AddressDetails:[]
    },
    reducers:{
        addAddressDetails(state,action){

        },
        removeAddressDetails(state, action){

        },
        updateAddressDetails(state,action){

        }
    }
});

export const{addAddressDetails, removeAddressDetails, updateAddressDetails}=CheckoutSlice.actions;

export default CheckoutSlice.reducer;
