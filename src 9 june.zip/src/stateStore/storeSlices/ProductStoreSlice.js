import {createSlice} from '@reduxjs/toolkit';

const ProductSlice=createSlice({
    name:"Product_Slice",
    initialState:[],
    reducers:{
        addProduct(state,action){

        },
    }
});

export const {addProduct}= ProductSlice.actions;

export default ProductSlice.reducer;
